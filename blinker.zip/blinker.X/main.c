/*
 * Blinking dsPIC30F1010 using XC16
 * in MPLABX IDE
 */
#include <p30F1010.h>
#include "config.h"

/*Nominal internal fast oscillator frequency of 15MHz*/
#define FCY 15000000UL
#include <libpic30.h>

void main(void){
    /*Additionaly select the maximum nominal frequency of 15MHz*/
    OSCTUNbits.TUN=0x07;
    /*Clear I/O of PORTE*/
    PORTE=0x0000;
    LATE=0x00000;
    /*PORTE direction as output*/
    TRISE=0x0000;
    while(1){
        /*Toggling RE5*/
        LATEbits.LATE5^=1;
        /*Wait for 0.5 second*/
        __delay_ms(500);
    }
}