/*
 * Blinking dsPIC30F1010 using XC16
 * in MPLABX IDE
 */
#include <p30F1010.h>
#include "config.h"

/*Nominal internal fast oscillator frequency of 15MHz*/
#define FCY 15000000UL
#include <libpic30.h>

/*LED connects to RE5*/
#define LED LATEbits.LATE5
/*Button connects to RE4*/
#define BTN PORTEbits.RE4

void main(void){
    /*Additionaly select the maximum nominal frequency of 15MHz*/
    OSCTUNbits.TUN=0x07;
    /*Clear I/O of PORTE*/
    PORTE=0x0000;
    LATE=0x00000;
    /*LED OUTPUT*/
    TRISEbits.TRISE5=0;
    /*Button INPUT*/
    TRISEbits.TRISE4=1;
    
    while(1){
        /*Check Input Button - active high*/
        if(BTN==1){
            while(BTN==1);
            LED^=1;
        }
    }
}